# Radio Dewi Anjani FM 104.6 — Flutter Android

## Struktur logo (sudah disertakan)
- `assets/logo_radio.webp` — logo ringan untuk tampilan dalam aplikasi.
- `assets/icon/logo_radio.png` — logo 512 × 512 untuk ikon aplikasi Android.

## Perbaikan kasus gagal build
Workflow `.github/workflows/build-apk.yml` membangun proyek langsung dari root repository.
Tidak ada langkah `Extract Flutter Project` dan tidak ada perintah `cp assets/icon/logo_radio.png ...`.
Karena itu, error `cannot stat 'assets/icon/logo_radio.png'` dari langkah Copy Radio Logo tidak terjadi selama seluruh isi ZIP ini diunggah ke root repository.

## Cara upload ke GitHub
1. Ekstrak ZIP ini di komputer.
2. Upload seluruh isi folder hasil ekstrak ke root repository GitHub (bukan folder luarnya).
3. Timpa file lama jika diminta.
4. Pastikan `pubspec.yaml`, `lib/`, `assets/`, `android/`, dan `.github/` terlihat langsung di root repository.
5. Buka Actions lalu jalankan `Build Android APK Radio Dewi Anjani`.

## Fitur
- Logo radio di halaman utama dan ikon launcher Android.
- Streaming audio latar belakang melalui `just_audio_background`.
- Kontrol media Android / notifikasi.
- Call / WA Center Siaran: 087793292112.
- APK dipisah per ABI untuk mengurangi ukuran unduhan.

## Catatan
Ukuran APK maksimal 5 MB tidak dapat dijamin oleh kompresi gambar. Flutter engine dan plugin audio memiliki ukuran dasar. Workflow menampilkan ukuran APK hasil build agar dapat diperiksa. Pilih APK `arm64-v8a` untuk kebanyakan HP Android modern.

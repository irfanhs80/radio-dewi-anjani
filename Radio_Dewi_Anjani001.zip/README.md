# RADIO DEWI ANJANI FM 104.6 MHz

Aplikasi Android Flutter Radio Dewi Anjani.

## Fitur
- Live streaming: https://i.klikhost.com/8140/1
- Audio latar belakang saat pengguna membuka aplikasi lain atau layar terkunci.
- Kontrol pemutaran melalui notifikasi/media controls Android.
- Logo radio pada halaman utama dan launcher Android.
- Jadwal siaran, profil radio, dan kontak.
- Call / WhatsApp Center Siaran: 087793292112.

## Optimasi
- Logo tampilan WebP 384 × 384.
- Ikon launcher PNG 512 × 512.
- APK dibangun terpisah per arsitektur CPU (`--split-per-abi`) agar ukuran unduhan lebih kecil.
- Build release menggunakan obfuscation dan pemisahan simbol debug.
- Aset gambar dikompresi.

## Build APK
1. Upload seluruh isi proyek ke root repository GitHub.
2. Pastikan workflow berada di `.github/workflows/build-apk.yml`.
3. Buka tab Actions dan jalankan workflow.
4. Unduh artifact `Radio-Dewi-Anjani-APK`.
5. Pilih APK sesuai arsitektur perangkat Android (arm64-v8a paling umum untuk HP modern).

## Catatan ukuran
Batas maksimal 5 MB tidak dapat dijamin hanya dengan kompresi aset. Flutter engine dan plugin audio memiliki ukuran dasar. Build per-ABI mengurangi ukuran dibanding APK universal, tetapi hasil akhir harus diperiksa setelah build.

## Catatan audio latar belakang
Pemutaran latar belakang menggunakan `just_audio_background` dan membutuhkan notifikasi media Android. Perilaku juga bergantung pada versi Android, izin notifikasi, optimasi baterai, dan server streaming.

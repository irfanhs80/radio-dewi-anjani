# Radio Dewi Anjani FM 104.6 — revised from proven-working Project001

This revision uses the uploaded Project001 as the baseline, preserving its pages and schedule.

## Updates
- Replaces the app logo with the latest supplied logo, retaining `assets/logo_radio.jpg` for compatibility with existing UI.
- Adds Android launcher icon generation.
- Changes player logic so `play()` is not awaited; this avoids blocking the UI while a live stream is playing.
- UI state follows the audio player's state stream.
- Shows `LIVE STREAMING` while audio is playing and removes the endless spinner from the play button.
- Adds background audio service and Android media notification configuration.
- Adds Call / WhatsApp Center Siaran 087793292112.
- Universal APK build includes supported Flutter Android ABIs; Google Play AAB also generated.

## Build from GitHub ZIP repository
The repository should contain `Radio_Dewi_Anjani001.zip` and `.github/workflows/build-apk.yml`.
The ZIP must contain `pubspec.yaml` at its root. Upload this project's contents as `Radio_Dewi_Anjani001.zip`.

## Important
This source is based on the user's working baseline but has not been compiled or device-tested in this environment. Test the resulting APK on physical ARM Android devices before release. Universal APK is larger than split APKs. Compatibility still depends on Android minSdk and supported CPU architectures.

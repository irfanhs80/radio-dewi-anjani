import 'dart:async';

import 'package:flutter/material.dart';
import 'package:just_audio/just_audio.dart';
import 'package:just_audio_background/just_audio_background.dart';
import 'package:audio_service/audio_service.dart';
import 'package:url_launcher/url_launcher.dart';

Future<void> main() async {
  WidgetsFlutterBinding.ensureInitialized();
  await JustAudioBackground.init(
    androidNotificationChannelId: 'id.radiodewianjani.audio',
    androidNotificationChannelName: 'Radio Dewi Anjani',
    androidNotificationOngoing: true,
  );
  runApp(const RadioApp());
}

const String streamUrl = 'https://i.klikhost.com/8140/1';
const String motto = 'Media Shilaturahmi Menggugah Inspirasi Ihwan Sejati';
const Color radioGreen = Color(0xFF087443);

class RadioApp extends StatelessWidget {
  const RadioApp({super.key});

  @override
  Widget build(BuildContext context) {
    return MaterialApp(
      debugShowCheckedModeBanner: false,
      title: 'RADIO DEWI ANJANI',
      theme: ThemeData(
        colorScheme: ColorScheme.fromSeed(seedColor: radioGreen),
        useMaterial3: true,
      ),
      home: const HomePage(),
    );
  }
}

class HomePage extends StatefulWidget {
  const HomePage({super.key});

  @override
  State<HomePage> createState() => _HomePageState();
}

class _HomePageState extends State<HomePage> {
  final AudioPlayer _player = AudioPlayer();
  StreamSubscription<PlayerState>? _playerSubscription;
  StreamSubscription<dynamic>? _errorSubscription;

  bool _loading = false;
  bool _playing = false;
  bool _sourceReady = false;
  int _tab = 0;

  @override
  void initState() {
    super.initState();

    _playerSubscription = _player.playerStateStream.listen((state) {
      if (!mounted) return;
      final isActive = state.playing &&
          state.processingState != ProcessingState.completed;
      setState(() {
        _playing = isActive;
        _loading = state.processingState == ProcessingState.loading;
      });
    });

    _errorSubscription = _player.playbackEventStream.listen(
      (_) {},
      onError: (Object error, StackTrace stackTrace) {
        if (!mounted) return;
        setState(() {
          _playing = false;
          _loading = false;
        });
        ScaffoldMessenger.of(context).showSnackBar(
          const SnackBar(
            content: Text('Streaming terputus. Silakan coba putar kembali.'),
          ),
        );
      },
    );
  }

  Future<void> _toggleRadio() async {
    if (_loading) return;

    if (_player.playing) {
      await _player.pause();
      if (mounted) setState(() => _playing = false);
      return;
    }

    setState(() => _loading = true);

    try {
      if (!_sourceReady) {
        await _player.setAudioSource(
          AudioSource.uri(
            Uri.parse(streamUrl),
            tag: const MediaItem(
              id: streamUrl,
              title: 'Radio Dewi Anjani FM 104.6',
              artist: 'Live Streaming • Lombok Timur',
              album: 'Radio Dewi Anjani',
            ),
          ),
        );
        _sourceReady = true;
      }

      // Jangan menunggu Future play() selesai: pada siaran langsung,
      // Future tersebut baru selesai saat pemutaran dihentikan.
      unawaited(_player.play());

      if (mounted) {
        setState(() {
          _loading = false;
          _playing = true;
        });
      }
    } catch (_) {
      _sourceReady = false;
      if (!mounted) return;
      setState(() {
        _loading = false;
        _playing = false;
      });
      ScaffoldMessenger.of(context).showSnackBar(
        const SnackBar(
          content: Text(
            'Streaming belum dapat diputar. Periksa koneksi internet dan coba lagi.',
          ),
        ),
      );
    }
  }

  @override
  void dispose() {
    _playerSubscription?.cancel();
    _errorSubscription?.cancel();
    _player.dispose();
    super.dispose();
  }

  @override
  Widget build(BuildContext context) {
    final pages = <Widget>[
      _homeContent(),
      const SchedulePage(),
      const ProfilePage(),
      const ContactPage(),
    ];

    return Scaffold(
      appBar: AppBar(
        backgroundColor: radioGreen,
        foregroundColor: Colors.white,
        title: const Text(
          'RADIO DEWI ANJANI',
          style: TextStyle(fontWeight: FontWeight.bold, fontSize: 17),
        ),
        centerTitle: true,
      ),
      body: IndexedStack(index: _tab, children: pages),
      bottomNavigationBar: NavigationBar(
        selectedIndex: _tab,
        onDestinationSelected: (value) => setState(() => _tab = value),
        destinations: const [
          NavigationDestination(icon: Icon(Icons.radio), label: 'Radio'),
          NavigationDestination(
            icon: Icon(Icons.calendar_month),
            label: 'Jadwal',
          ),
          NavigationDestination(
            icon: Icon(Icons.info_outline),
            label: 'Profil',
          ),
          NavigationDestination(icon: Icon(Icons.call), label: 'Kontak'),
        ],
      ),
    );
  }

  Widget _homeContent() {
    final status = _loading
        ? 'MENGHUBUNGKAN KE SIARAN...'
        : _playing
            ? 'LIVE STREAMING'
            : 'TEKAN UNTUK MENDENGARKAN';

    return ListView(
      padding: const EdgeInsets.all(16),
      children: [
        Container(
          padding: const EdgeInsets.all(20),
          decoration: BoxDecoration(
            borderRadius: BorderRadius.circular(22),
            gradient: const LinearGradient(
              colors: [Color(0xFF075B36), Color(0xFF16A36A)],
              begin: Alignment.topLeft,
              end: Alignment.bottomRight,
            ),
          ),
          child: Column(
            children: [
              ClipOval(
                child: Image.asset(
                  'assets/logo_radio.webp',
                  width: 136,
                  height: 136,
                  fit: BoxFit.cover,
                  cacheWidth: 272,
                  cacheHeight: 272,
                ),
              ),
              const SizedBox(height: 10),
              const Text(
                'RADIO DEWI ANJANI',
                textAlign: TextAlign.center,
                style: TextStyle(
                  color: Colors.white,
                  fontWeight: FontWeight.w900,
                  fontSize: 22,
                ),
              ),
              const Text(
                'FM 104.6 MHz • Lombok Timur',
                style: TextStyle(color: Colors.white, fontSize: 14),
              ),
              const SizedBox(height: 10),
              const Text(
                motto,
                textAlign: TextAlign.center,
                style: TextStyle(color: Colors.white, fontStyle: FontStyle.italic),
              ),
            ],
          ),
        ),
        const SizedBox(height: 22),
        const Center(
          child: Text(
            'SIARAN LANGSUNG',
            style: TextStyle(fontWeight: FontWeight.bold, letterSpacing: 1.3),
          ),
        ),
        const SizedBox(height: 14),
        Center(
          child: Semantics(
            button: true,
            label: _playing ? 'Hentikan siaran radio' : 'Putar siaran radio',
            child: InkWell(
              onTap: _toggleRadio,
              borderRadius: BorderRadius.circular(60),
              child: CircleAvatar(
                radius: 46,
                backgroundColor: radioGreen,
                child: Icon(
                  _playing ? Icons.pause_rounded : Icons.play_arrow_rounded,
                  color: Colors.white,
                  size: 60,
                ),
              ),
            ),
          ),
        ),
        const SizedBox(height: 12),
        Center(
          child: Container(
            padding: const EdgeInsets.symmetric(horizontal: 18, vertical: 9),
            decoration: BoxDecoration(
              color: _playing ? const Color(0xFFE5F5EC) : const Color(0xFFF1F3F2),
              borderRadius: BorderRadius.circular(30),
            ),
            child: Row(
              mainAxisSize: MainAxisSize.min,
              children: [
                if (_playing)
                  const Padding(
                    padding: EdgeInsets.only(right: 7),
                    child: Icon(Icons.circle, size: 9, color: Colors.red),
                  ),
                Text(
                  status,
                  style: TextStyle(
                    color: _playing ? radioGreen : Colors.black87,
                    fontWeight: FontWeight.bold,
                    fontSize: 12,
                    letterSpacing: 0.5,
                  ),
                ),
              ],
            ),
          ),
        ),
        const SizedBox(height: 22),
        const InfoTile(
          icon: Icons.access_time,
          title: 'Jam Siaran',
          subtitle: 'Setiap hari, pukul 05.00–23.00 WITA',
        ),
        const InfoTile(
          icon: Icons.location_on,
          title: 'Studio',
          subtitle:
              'Komplek Kampus Universitas Islam Hamzanwadi NW Anjani, Lombok Timur',
        ),
        const InfoTile(
          icon: Icons.language,
          title: 'Website',
          subtitle: 'www.radiodewianjani.my.id',
        ),
      ],
    );
  }
}

class InfoTile extends StatelessWidget {
  final IconData icon;
  final String title;
  final String subtitle;

  const InfoTile({
    super.key,
    required this.icon,
    required this.title,
    required this.subtitle,
  });

  @override
  Widget build(BuildContext context) {
    return Card(
      child: ListTile(
        leading: Icon(icon, color: radioGreen),
        title: Text(title, style: const TextStyle(fontWeight: FontWeight.bold)),
        subtitle: Text(subtitle),
      ),
    );
  }
}

class SchedulePage extends StatelessWidget {
  const SchedulePage({super.key});

  static const schedule = [
    ['05:00–06:00', 'Siroh Islam (Siraman Rohani)'],
    ['06:30–08:00', 'Dewi Anjani Menyapa'],
    ['08:00–09:30', 'Majlis Hamzanwadi'],
    ['09:30–10:00', 'Lakaq Sasak'],
    ['10:00–12:00', 'Salam Dangdut'],
    ['13:00–14:00', 'Tembang Kenangan'],
    ['14:00–15:00', 'SIRASI (Silaturrahmi Siang)'],
    ['16:00–17:30', 'PILPEN (Pilihan Pendengar)'],
    ['18:30–19:30', 'DAI (Dakwah Agama Islam)'],
    ['20:00–22:00', 'CINTA (Cerita Diantara Kita)'],
    ['22:00–23:00', 'Renungan Malam'],
  ];

  @override
  Widget build(BuildContext context) {
    return ListView(
      padding: const EdgeInsets.all(16),
      children: [
        const Text(
          'JADWAL SIARAN HARIAN',
          style: TextStyle(fontWeight: FontWeight.bold, fontSize: 18),
        ),
        const SizedBox(height: 10),
        ...schedule.map(
          (item) => Card(
            child: ListTile(
              leading: const Icon(Icons.schedule, color: radioGreen),
              title: Text(item[1]),
              subtitle: Text(item[0]),
            ),
          ),
        ),
        const SizedBox(height: 12),
        const Text(
          'PROGRAM MINGGUAN',
          style: TextStyle(fontWeight: FontWeight.bold, fontSize: 18),
        ),
        const SizedBox(height: 8),
        const InfoTile(
          icon: Icons.event,
          title: 'Ahad',
          subtitle:
              '09.00–11.00 Panggung Ceria • 16.00–17.30 Voice Religi • 19.00–20.00 Hizib Nahdlatul Wathan',
        ),
        const InfoTile(
          icon: Icons.event,
          title: 'Selasa',
          subtitle: '19.00–22.00 Tanya Jawab Agama Islam',
        ),
        const InfoTile(
          icon: Icons.event,
          title: 'Kamis',
          subtitle: '19.00–20.00 Al-Barzanji',
        ),
        const InfoTile(
          icon: Icons.event,
          title: 'Jumat',
          subtitle:
              '07.00–10.00 Majlis Dakwah Hamzanwadi • 14.00–15.30 Podcast Santri • 16.00–17.30 Language Club',
        ),
      ],
    );
  }
}

class ProfilePage extends StatelessWidget {
  const ProfilePage({super.key});

  @override
  Widget build(BuildContext context) {
    return ListView(
      padding: const EdgeInsets.all(18),
      children: const [
        Text(
          'PROFIL RADIO',
          style: TextStyle(fontSize: 20, fontWeight: FontWeight.bold),
        ),
        SizedBox(height: 12),
        Text(
          'Radio Dewi Anjani FM 104.6 MHz merupakan radio komunitas dan dakwah yang hadir untuk menyampaikan informasi, pendidikan, dakwah Islam, hiburan positif, serta melestarikan budaya lokal.',
        ),
        SizedBox(height: 14),
        InfoTile(
          icon: Icons.business,
          title: 'Badan Usaha',
          subtitle: 'PT. Radio Bio Perdana Jaya',
        ),
        InfoTile(
          icon: Icons.calendar_today,
          title: 'Berdiri',
          subtitle: '13 November 2001',
        ),
        InfoTile(
          icon: Icons.school,
          title: 'Pengelola',
          subtitle:
              'Yayasan Ponpes Syaikh Zainuddin Nahdlatul Wathan Anjani, Lombok Timur',
        ),
        InfoTile(icon: Icons.campaign, title: 'Motto', subtitle: motto),
      ],
    );
  }
}

class ContactPage extends StatelessWidget {
  const ContactPage({super.key});

  Future<void> _open(String value) async {
    final uri = Uri.parse(value);
    await launchUrl(uri, mode: LaunchMode.externalApplication);
  }

  @override
  Widget build(BuildContext context) {
    return ListView(
      padding: const EdgeInsets.all(18),
      children: [
        const Text(
          'HUBUNGI RADIO DEWI ANJANI',
          style: TextStyle(fontSize: 19, fontWeight: FontWeight.bold),
        ),
        const SizedBox(height: 12),
        const InfoTile(
          icon: Icons.phone,
          title: 'Telepon Kantor',
          subtitle: '+62 817-5760-897',
        ),
        const InfoTile(
          icon: Icons.support_agent,
          title: 'Call / WA Center Siaran',
          subtitle: '087793292112',
        ),
        const InfoTile(
          icon: Icons.email,
          title: 'Email',
          subtitle: 'dewianjani1046@gmail.com',
        ),
        const InfoTile(
          icon: Icons.web,
          title: 'Website',
          subtitle: 'www.radiodewianjani.my.id',
        ),
        const SizedBox(height: 12),
        FilledButton.icon(
          onPressed: () => _open('https://wa.me/6287793292112'),
          icon: const Icon(Icons.chat),
          label: const Text('WhatsApp Center Siaran'),
        ),
        OutlinedButton.icon(
          onPressed: () => _open('tel:087793292112'),
          icon: const Icon(Icons.call),
          label: const Text('Telepon Center Siaran'),
        ),
        OutlinedButton.icon(
          onPressed: () => _open('https://www.radiodewianjani.my.id'),
          icon: const Icon(Icons.language),
          label: const Text('Kunjungi Website'),
        ),
      ],
    );
  }
}
